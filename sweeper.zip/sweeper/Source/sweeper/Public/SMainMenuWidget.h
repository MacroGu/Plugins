// Copyright (c) 2021, Macro Gu <macro.gu@gmail.com>. All Rights Reserved.


#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Layout/SGridPanel.h"





#define MAX_GRID_WIDTH 4
#define MAX_GRID_HEGIHT 4


class SMainMenuWidget : public SCompoundWidget
{

public:
	SLATE_BEGIN_ARGS(SMainMenuWidget) {}

	SLATE_END_ARGS()

		void Construct(const FArguments& InArgs);

	virtual bool SupportsKeyboardFocus() const override { return true; }

	void OnWidthTextChanged(const FText& Text);
	void OnHeightTextChanged(const FText& Text);
	void OnMinesTextChanged(const FText& Text);
	FReply OnGenerateNewGrid();

	bool CheckIsBomb(const int32& w, const int32& h);

	void InitBombsInGrid(const int32& w, const int32& h, const int32& m);

public:
	// call back function for grid
	FReply OnGridButton(int32 w, int32 h);

private:
	int32 Width;
	int32 Height;
	int32 Mines;

	SGridPanel::FSlot* ButtonSlot[MAX_GRID_WIDTH][MAX_GRID_HEGIHT];
	SOverlay::FOverlaySlot* CurrentWidget;

private:

	int32 AllGrids[MAX_GRID_WIDTH][MAX_GRID_HEGIHT];		// 0 is not bomb, 1 is bomb

};