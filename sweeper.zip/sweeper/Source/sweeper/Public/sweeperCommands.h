// Copyright (c) 2021, Macro Gu <macro.gu@gmail.com>. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Framework/Commands/Commands.h"
#include "sweeperStyle.h"

class FsweeperCommands : public TCommands<FsweeperCommands>
{
public:

	FsweeperCommands()
		: TCommands<FsweeperCommands>(TEXT("sweeper"), NSLOCTEXT("Contexts", "sweeper", "sweeper Plugin"), NAME_None, FsweeperStyle::GetStyleSetName())
	{
	}

	// TCommands<> interface
	virtual void RegisterCommands() override;

public:
	TSharedPtr< FUICommandInfo > OpenPluginWindow;
};