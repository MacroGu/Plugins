// Copyright (c) 2021, Macro Gu <macro.gu@gmail.com>. All Rights Reserved.

#include "sweeper.h"
#include "sweeperStyle.h"
#include "sweeperCommands.h"
#include "LevelEditor.h"
#include "Widgets/Docking/SDockTab.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Text/STextBlock.h"
#include "SMainMenuWidget.h"
#include "ToolMenus.h"

static const FName sweeperTabName("sweeper");

#define LOCTEXT_NAMESPACE "FsweeperModule"

void FsweeperModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
	
	FsweeperStyle::Initialize();
	FsweeperStyle::ReloadTextures();

	FsweeperCommands::Register();
	
	PluginCommands = MakeShareable(new FUICommandList);

	PluginCommands->MapAction(
		FsweeperCommands::Get().OpenPluginWindow,
		FExecuteAction::CreateRaw(this, &FsweeperModule::PluginButtonClicked),
		FCanExecuteAction());

	UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FsweeperModule::RegisterMenus));
	
	FGlobalTabmanager::Get()->RegisterNomadTabSpawner(sweeperTabName, FOnSpawnTab::CreateRaw(this, &FsweeperModule::OnSpawnPluginTab))
		.SetDisplayName(LOCTEXT("FsweeperTabTitle", "sweeper"))
		.SetMenuType(ETabSpawnerMenuType::Hidden);
}

void FsweeperModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.

	UToolMenus::UnRegisterStartupCallback(this);

	UToolMenus::UnregisterOwner(this);

	FsweeperStyle::Shutdown();

	FsweeperCommands::Unregister();

	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(sweeperTabName);
}

TSharedRef<SDockTab> FsweeperModule::OnSpawnPluginTab(const FSpawnTabArgs& SpawnTabArgs)
{
	FText WidgetText = FText::Format(
		LOCTEXT("WindowWidgetText", "Add code to {0} in {1} to override this window's contents"),
		FText::FromString(TEXT("FsweeperModule::OnSpawnPluginTab")),
		FText::FromString(TEXT("sweeper.cpp"))
		);

	// �ı��Ͱ�ť�������
	const FMargin ContentPadding = FMargin(500.0f, 300.0f);
	const FMargin ButtonPadding = FMargin(10.f);
	// ��ť�ͱ����ı�
	const FText TitleText = LOCTEXT("SlateTest", "Just a Slate Test");
	const FText PlayText = LOCTEXT("PlayGame", "Play");
	const FText QuitText = LOCTEXT("QuitGame", "Quit Game");
	//��ť���弰��С����
	FSlateFontInfo ButtonTextStyle = FCoreStyle::Get().GetFontStyle("EmbossedText");
	ButtonTextStyle.Size = 40.f;
	//�������弰��С����
	FSlateFontInfo TitleTextStyle = ButtonTextStyle;
	TitleTextStyle.Size = 60.f;

	return SNew(SDockTab)
		.TabRole(ETabRole::NomadTab)
		[
			SNew(SMainMenuWidget)
		];
}

void FsweeperModule::PluginButtonClicked()
{
	FGlobalTabmanager::Get()->TryInvokeTab(sweeperTabName);
}

void FsweeperModule::RegisterMenus()
{
	// Owner will be used for cleanup in call to UToolMenus::UnregisterOwner
	FToolMenuOwnerScoped OwnerScoped(this);

	{
		UToolMenu* Menu = UToolMenus::Get()->ExtendMenu("LevelEditor.MainMenu.Window");
		{
			FToolMenuSection& Section = Menu->FindOrAddSection("WindowLayout");
			Section.AddMenuEntryWithCommandList(FsweeperCommands::Get().OpenPluginWindow, PluginCommands);
		}
	}

	{
		UToolMenu* ToolbarMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.LevelEditorToolBar");
		{
			FToolMenuSection& Section = ToolbarMenu->FindOrAddSection("Settings");
			{
				FToolMenuEntry& Entry = Section.AddEntry(FToolMenuEntry::InitToolBarButton(FsweeperCommands::Get().OpenPluginWindow));
				Entry.SetCommandList(PluginCommands);
			}
		}
	}
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FsweeperModule, sweeper)