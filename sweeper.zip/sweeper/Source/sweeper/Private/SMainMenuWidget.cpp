// Copyright (c) 2021, Macro Gu <macro.gu@gmail.com>. All Rights Reserved.

#include "SMainMenuWidget.h"
#include "Engine/World.h"
#include <vector>
#include <algorithm>


#if WITH_EDITOR
#define LOCTEXT_NAMESPACE "MAINMENUWIDGET"

void SMainMenuWidget::Construct(const FArguments& InArgs)
{
	std::srand(unsigned(std::time(0)));

	//����UI�ؼ���д������
	ChildSlot
		.VAlign(VAlign_Fill)
		.HAlign(HAlign_Fill)
		[
			SNew(SOverlay)

			+ SOverlay::Slot()
				.VAlign(VAlign_Top)
				.HAlign(HAlign_Fill)
				[
					SNew(SVerticalBox)

					// first row
					+ SVerticalBox::Slot()
					.VAlign(VAlign_Top)
					.HAlign(HAlign_Fill)
					[
						SNew(SHorizontalBox)

						+ SHorizontalBox::Slot()
							.Padding(1.0f)
							.HAlign(HAlign_Fill)
							.FillWidth(1)
							[
								SNew(SHorizontalBox)
								+ SHorizontalBox::Slot()
// 									.Padding(22)
 									.HAlign(HAlign_Left)
									.FillWidth(1)
									[
										SNew(STextBlock)
										.Text(FText::FromString("Width : "))
									]

								+ SHorizontalBox::Slot()
// 									.Padding(22)
 									.HAlign(HAlign_Fill)
									.FillWidth(3)
									[
										SNew(SEditableTextBox)
										.OnTextChanged(this, &SMainMenuWidget::OnWidthTextChanged)
									]
							]


						+ SHorizontalBox::Slot()
							.FillWidth(1)
							[
								SNew(SHorizontalBox)
								+SHorizontalBox::Slot()
									.FillWidth(1)
									.HAlign(HAlign_Left)
									[
										SNew(STextBlock)
										.Text(FText::FromString("Height : "))
									]

								+ SHorizontalBox::Slot()
									.FillWidth(3)
									.HAlign(HAlign_Fill)
									[
										// repository path text box
										SNew(SEditableTextBox)
										.OnTextChanged(this, &SMainMenuWidget::OnHeightTextChanged)
									]
							]
					]


				// second row
				+SVerticalBox::Slot()
					.VAlign(VAlign_Top)
					.HAlign(HAlign_Fill)
					[
						SNew(SHorizontalBox)

						+ SHorizontalBox::Slot()
						[
						SNew(SHorizontalBox)
						+ SHorizontalBox::Slot()
							.FillWidth(1)
							.HAlign(HAlign_Left)
								[
									SNew(STextBlock)
									.Text(FText::FromString("Number Of Mines : "))
								]

						+ SHorizontalBox::Slot()
							.FillWidth(3)
							.HAlign(HAlign_Fill)
								[
									SNew(SEditableTextBox)
									.OnTextChanged(this, &SMainMenuWidget::OnMinesTextChanged)
								]
						]

						+ SHorizontalBox::Slot()
							[
								SNew(SHorizontalBox)

							]

					]

				// third row
				+ SVerticalBox::Slot()
					.VAlign(VAlign_Top)
					.HAlign(HAlign_Fill)
					[
						SNew(SHorizontalBox)

						+ SHorizontalBox::Slot().HAlign(HAlign_Center).VAlign(VAlign_Center).AutoWidth()
						[
							SNew(SButton).OnClicked(this, &SMainMenuWidget::OnGenerateNewGrid)
							[
								SNew(STextBlock).Text(FText::FromString(TEXT("Generate new grid")))
							]
						]
					]
				]

			// add buttons
				+ SOverlay::Slot()
					.HAlign(HAlign_Center)
					.VAlign(VAlign_Center)
					.Expose(CurrentWidget)
					[
						SNew(SGridPanel)				

					+ SGridPanel::Slot(0, 0).Expose(ButtonSlot[0][0])
						[
							SNew(SButton).OnClicked(this, &SMainMenuWidget::OnGridButton, 0, 0) //.VAlign(VAlign_Center).HAlign(HAlign_Center).Text(FText::FromString("0"))
						]

					+ SGridPanel::Slot(0, 1).Expose(ButtonSlot[0][1])
						[
							SNew(SButton).OnClicked(this, &SMainMenuWidget::OnGridButton, 0, 1)
						]

					+ SGridPanel::Slot(0, 2).Expose(ButtonSlot[0][2])
						[
							SNew(SButton).OnClicked(this, &SMainMenuWidget::OnGridButton, 0, 2)
						]

					+ SGridPanel::Slot(0, 3).Expose(ButtonSlot[0][3])
						[
							SNew(SButton).OnClicked(this, &SMainMenuWidget::OnGridButton, 0, 3)
						]

					+ SGridPanel::Slot(1, 0).Expose(ButtonSlot[1][0])
						[
							SNew(SButton).OnClicked(this, &SMainMenuWidget::OnGridButton, 1, 0)
						]

					+ SGridPanel::Slot(1, 1).Expose(ButtonSlot[1][1])
						[
							SNew(SButton).OnClicked(this, &SMainMenuWidget::OnGridButton, 1, 1)
						]

					+ SGridPanel::Slot(1, 2).Expose(ButtonSlot[1][2])
						[
							SNew(SButton).OnClicked(this, &SMainMenuWidget::OnGridButton, 1, 2)
						]

					+ SGridPanel::Slot(1, 3).Expose(ButtonSlot[1][3])
						[
							SNew(SButton).OnClicked(this, &SMainMenuWidget::OnGridButton, 1, 3)
						]

					+ SGridPanel::Slot(2, 0).Expose(ButtonSlot[2][0])
						[
							SNew(SButton).OnClicked(this, &SMainMenuWidget::OnGridButton, 2, 0)
						]

					+ SGridPanel::Slot(2, 1).Expose(ButtonSlot[2][1])
						[
							SNew(SButton).OnClicked(this, &SMainMenuWidget::OnGridButton, 2, 1)
						]

					+ SGridPanel::Slot(2, 2).Expose(ButtonSlot[2][2])
						[
							SNew(SButton).OnClicked(this, &SMainMenuWidget::OnGridButton, 2, 2)
						]

					+ SGridPanel::Slot(2, 3).Expose(ButtonSlot[2][3])
						[
							SNew(SButton).OnClicked(this, &SMainMenuWidget::OnGridButton, 2, 3)
						]

					+ SGridPanel::Slot(3, 0).Expose(ButtonSlot[3][0])
						[
							SNew(SButton).OnClicked(this, &SMainMenuWidget::OnGridButton, 3, 0)
						]

					+ SGridPanel::Slot(3, 1).Expose(ButtonSlot[3][1])
						[
							SNew(SButton).OnClicked(this, &SMainMenuWidget::OnGridButton, 3, 1)
						]

					+ SGridPanel::Slot(3, 2).Expose(ButtonSlot[3][2])
						[
							SNew(SButton).OnClicked(this, &SMainMenuWidget::OnGridButton, 3, 2)
						]

					+ SGridPanel::Slot(3, 3).Expose(ButtonSlot[3][3])
						[
							SNew(SButton).OnClicked(this, &SMainMenuWidget::OnGridButton, 3, 3)
						]

				]
		];
}

void SMainMenuWidget::OnWidthTextChanged(const FText& Text)
{
	int32 new_width = FCString::Atoi(*Text.ToString());
	if (new_width <= 0 || new_width > MAX_GRID_WIDTH)
	{
		GEngine->AddOnScreenDebugMessage(-1, 50.f, FColor::Blue, FString::Printf(TEXT("width should between 0 and %i"), MAX_GRID_WIDTH));
		return;
	}
	 
	Width = new_width;
}

void SMainMenuWidget::OnHeightTextChanged(const FText& Text)
{
	int32 new_height = FCString::Atoi(*Text.ToString());
	if (new_height <= 0 || new_height > MAX_GRID_HEGIHT)
	{
		GEngine->AddOnScreenDebugMessage(-1, 50.f, FColor::Blue, FString::Printf(TEXT("height should between 0 and %i"), MAX_GRID_HEGIHT));
		return;
	}

	Height = new_height;

}


void SMainMenuWidget::OnMinesTextChanged(const FText& Text)
{

	int32 new_Mines = FCString::Atoi(*Text.ToString());

	if (new_Mines == 0 && !Text.ToString().Equals("0"))
	{
		GEngine->AddOnScreenDebugMessage(-1, 50.f, FColor::Blue, TEXT("Mines should be a number"));
		return;
	}

	int32 cur_total_grids = Width * Height;

	if (new_Mines < 0 || new_Mines > cur_total_grids)
	{
		GEngine->AddOnScreenDebugMessage(-1, 50.f, FColor::Blue, FString::Printf(TEXT("Mines should between 0 and %i"), cur_total_grids));
		return;
	}

	Mines = new_Mines;
}

FReply SMainMenuWidget::OnGenerateNewGrid()
{
	GEngine->AddOnScreenDebugMessage(-1, 50.f, FColor::Blue, TEXT("OnGenerateNewGrid"));

	InitBombsInGrid(Width, Height, Mines);

	for (int32 w = 0; w < MAX_GRID_WIDTH; ++w)
	{
		for (int32 h = 0; h < MAX_GRID_HEGIHT; ++h)
		{
			if (w > Width - 1 || h > Height - 1)
			{
				ButtonSlot[w][h]->DetachWidget();
			}
		}
	}

	return FReply::Handled();
}

bool SMainMenuWidget::CheckIsBomb(const int32& w, const int32& h)
{
	if (AllGrids[w][h] == 1)
	{
		FText DialogText = FText::Format(
			LOCTEXT("Failed!", " this is a bomb, you failed!{0}"),
			FText::FromString("")
		);

		FMessageDialog::Debugf(DialogText); //����Ĭ�ϵ�ϵͳԭ����Ϣ�Ի���

		return true;
	}

	return false;
}

void SMainMenuWidget::InitBombsInGrid(const int32& w, const int32& h, const int32& m)
{
	if (w > MAX_GRID_WIDTH || w < 0 || h > MAX_GRID_HEGIHT || h < 0 || m < 0 || m > w * h)
	{
		return;
	}

	std::vector<int32> all_random_grids;
	int32 bombs = 0;
	for (int32 i = 0 ; i < w ; ++i)
	{
		for (int32 j = 0; j < h; ++j)
		{
			if (bombs < m)
			{
				all_random_grids.push_back(1);
				++bombs;
			}
			else
			{
				all_random_grids.push_back(0);
			}
		}
	}

	std::random_shuffle(all_random_grids.begin(), all_random_grids.end());
	int32 pos = 0;
	for (int32 i = 0; i < w; ++i)
	{
		for (int32 j = 0; j < h; ++j)
		{
			AllGrids[i][j] = all_random_grids[pos];
			++pos;
		}
	}

	// CurrentWidget = ButtonSlot[0][0];
}

FReply SMainMenuWidget::OnGridButton(int32 w, int32 h)
{
	if (!CheckIsBomb(w, h))
	{
		ButtonSlot[w][h]->DetachWidget();
	}

	return FReply::Handled();
}


#undef LOCTEXT_NAMESPACE
#endif