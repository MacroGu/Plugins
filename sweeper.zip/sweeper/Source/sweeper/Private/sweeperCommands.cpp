// Copyright (c) 2021, Macro Gu <macro.gu@gmail.com>. All Rights Reserved.

#include "sweeperCommands.h"

#define LOCTEXT_NAMESPACE "FsweeperModule"

void FsweeperCommands::RegisterCommands()
{
	UI_COMMAND(OpenPluginWindow, "sweeper", "Bring up sweeper window", EUserInterfaceActionType::Button, FInputGesture());
}

#undef LOCTEXT_NAMESPACE
